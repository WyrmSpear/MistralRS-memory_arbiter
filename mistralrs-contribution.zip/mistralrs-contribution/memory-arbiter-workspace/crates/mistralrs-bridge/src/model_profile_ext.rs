//! Extension trait for constructing [`ModelProfile`]s from mistral.rs
//! configuration and GGUF/safetensor metadata.
//!
//! Once merged upstream, these helpers would live alongside mistral.rs's
//! existing `ModelConfig` types so that the arbiter can be invoked
//! transparently during model load.

use memory_arbiter::model_profile::{DType, ModelProfile};

/// Extension methods for constructing [`ModelProfile`] from common sources.
pub trait ModelProfileExt: Sized {
    /// Build from mistral.rs's GGUF metadata map.
    ///
    /// Reads the standard GGUF keys:
    /// * `llm.block_count`
    /// * `llm.embedding_length`
    /// * `llm.attention.head_count`
    /// * `llm.attention.head_count_kv`
    /// * `llm.feed_forward_length`
    /// * `tokenizer.ggml.tokens` (length = vocab size)
    ///
    /// # Errors
    /// Returns an error string if any required key is missing or invalid.
    fn from_gguf_metadata(
        name: &str,
        metadata: &std::collections::HashMap<String, serde_json::Value>,
        dtype: DType,
    ) -> Result<Self, String>;

    /// Build from a mistral.rs `config.json`-style map (HuggingFace format).
    ///
    /// # Errors
    /// Returns an error string if required fields are absent.
    fn from_hf_config(
        name: &str,
        config: &std::collections::HashMap<String, serde_json::Value>,
        dtype: DType,
    ) -> Result<Self, String>;
}

impl ModelProfileExt for ModelProfile {
    fn from_gguf_metadata(
        name: &str,
        meta: &std::collections::HashMap<String, serde_json::Value>,
        dtype: DType,
    ) -> Result<Self, String> {
        let get_u = |key: &str| -> Result<usize, String> {
            meta.get(key)
                .and_then(|v| v.as_u64())
                .map(|v| v as usize)
                .ok_or_else(|| format!("GGUF key missing or invalid: {key}"))
        };

        let num_layers = get_u("llm.block_count")?;
        let hidden_size = get_u("llm.embedding_length")?;
        let num_attention_heads = get_u("llm.attention.head_count")?;
        let num_kv_heads = get_u("llm.attention.head_count_kv")
            .unwrap_or(num_attention_heads);
        let intermediate_size = get_u("llm.feed_forward_length")?;

        // Vocab size: prefer explicit key, fall back to token list length.
        let vocab_size = get_u("llm.vocab_size").or_else(|_| {
            meta.get("tokenizer.ggml.tokens")
                .and_then(|v| v.as_array())
                .map(|a| a.len())
                .ok_or_else(|| "Cannot determine vocab_size from GGUF".to_string())
        })?;

        Ok(ModelProfile {
            name: name.to_string(),
            num_layers,
            hidden_size,
            num_attention_heads,
            num_kv_heads,
            intermediate_size,
            vocab_size,
            // Sensible defaults; override as needed.
            max_seq_len: 32768,
            kv_cache_batch: 1,
            dtype,
        })
    }

    fn from_hf_config(
        name: &str,
        config: &std::collections::HashMap<String, serde_json::Value>,
        dtype: DType,
    ) -> Result<Self, String> {
        let get_u = |key: &str| -> Result<usize, String> {
            // HF configs use both integer and string forms.
            config
                .get(key)
                .and_then(|v| v.as_u64().or_else(|| v.as_str()?.parse().ok()))
                .map(|v| v as usize)
                .ok_or_else(|| format!("HF config key missing: {key}"))
        };

        // Llama/Mistral family keys.
        let num_layers = get_u("num_hidden_layers")?;
        let hidden_size = get_u("hidden_size")?;
        let num_attention_heads = get_u("num_attention_heads")?;
        let num_kv_heads = get_u("num_key_value_heads").unwrap_or(num_attention_heads);
        let intermediate_size = get_u("intermediate_size")?;
        let vocab_size = get_u("vocab_size")?;
        let max_seq_len = get_u("max_position_embeddings").unwrap_or(32768);

        Ok(ModelProfile {
            name: name.to_string(),
            num_layers,
            hidden_size,
            num_attention_heads,
            num_kv_heads,
            intermediate_size,
            vocab_size,
            max_seq_len,
            kv_cache_batch: 1,
            dtype,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashMap;

    #[test]
    fn from_hf_config_mistral_7b() {
        let mut config = HashMap::new();
        config.insert("num_hidden_layers".into(), serde_json::json!(32));
        config.insert("hidden_size".into(), serde_json::json!(4096));
        config.insert("num_attention_heads".into(), serde_json::json!(32));
        config.insert("num_key_value_heads".into(), serde_json::json!(8));
        config.insert("intermediate_size".into(), serde_json::json!(14336));
        config.insert("vocab_size".into(), serde_json::json!(32000));
        config.insert("max_position_embeddings".into(), serde_json::json!(32768));

        let profile = ModelProfile::from_hf_config("test-7b", &config, DType::Q4_K_M).unwrap();
        assert_eq!(profile.num_layers, 32);
        assert_eq!(profile.num_kv_heads, 8);
    }
}
