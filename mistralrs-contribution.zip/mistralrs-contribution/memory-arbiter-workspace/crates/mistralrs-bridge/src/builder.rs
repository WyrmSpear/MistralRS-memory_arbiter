//! [`ArbiterPipelineBuilder`] — high-level builder for optimal mistral.rs
//! launch configuration.
//!
//! This is the primary user-facing API.  It abstracts over hardware probing,
//! plan computation, and config-file generation so users can just call
//! `ArbiterPipelineBuilder::for_model(profile).build()` and get back
//! a ready-to-use launch configuration.

use memory_arbiter::{
    arbiter::{ArbiterConfig, MemoryArbiter},
    model_profile::ModelProfile,
    plan::AllocationPlan,
};
use tracing::info;

use crate::device_map::MistralrsDeviceMapMetadata;

/// The output of `ArbiterPipelineBuilder::build()`.
#[derive(Debug, Clone)]
pub struct PipelineLaunchConfig {
    /// The computed allocation plan.
    pub plan: AllocationPlan,
    /// mistral.rs formatted metadata.
    pub metadata: MistralrsDeviceMapMetadata,
    /// Ready-to-use CLI args for `mistral.rs`.
    pub cli_args: Vec<String>,
    /// TOML config snippet.
    pub toml_snippet: String,
}

impl PipelineLaunchConfig {
    /// Print a human-friendly summary.
    pub fn print_summary(&self) {
        println!("{}", self.plan);
        println!("=== mistral.rs Launch Configuration ===");
        println!("  CLI:  {}", self.cli_args.join(" "));
        println!("{}", self.toml_snippet);
    }
}

/// Builder for computing and applying the best device map for a model.
pub struct ArbiterPipelineBuilder {
    model: ModelProfile,
    arbiter_config: ArbiterConfig,
}

impl ArbiterPipelineBuilder {
    /// Start building with the given model profile.
    #[must_use]
    pub fn for_model(model: ModelProfile) -> Self {
        Self {
            model,
            arbiter_config: ArbiterConfig::default(),
        }
    }

    /// Override the default arbiter configuration.
    #[must_use]
    pub fn with_arbiter_config(mut self, config: ArbiterConfig) -> Self {
        self.arbiter_config = config;
        Some(self).unwrap()
    }

    /// Set a custom VRAM safety margin (0.0–1.0).
    #[must_use]
    pub fn vram_safety_margin(mut self, margin: f64) -> Self {
        self.arbiter_config.vram_safety_margin = margin;
        self
    }

    /// Disable KV-cache GPU placement to save VRAM at the cost of bandwidth.
    #[must_use]
    pub fn kv_cache_on_cpu(mut self) -> Self {
        self.arbiter_config.kv_cache_on_gpu = false;
        self
    }

    /// Probe hardware and compute the optimal launch configuration.
    ///
    /// # Errors
    /// Returns an error if hardware probing fails.
    pub fn build(self) -> Result<PipelineLaunchConfig, String> {
        let mut arbiter = MemoryArbiter::new(self.arbiter_config);
        let plan = arbiter.plan(&self.model)?;

        info!(
            target: "mistralrs_bridge::builder",
            gpu_layers = plan.gpu_layer_count,
            cpu_layers = plan.cpu_layer_count,
            model = %plan.model_name,
            "ArbiterPipelineBuilder: plan computed"
        );

        let metadata = MistralrsDeviceMapMetadata::from_plan(&plan);
        let cli_args = metadata.to_cli_args();
        let toml_snippet = metadata.to_toml_snippet();

        Ok(PipelineLaunchConfig {
            plan,
            metadata,
            cli_args,
            toml_snippet,
        })
    }
}
