//! [`LiveRebalancer`] — a Tokio task that watches [`PressureEvent`]s and
//! triggers pipeline re-plans when memory pressure changes.
//!
//! This requires a model pipeline that supports hot-reload of its device map.
//! mistral.rs does not yet support this natively, but the infrastructure is
//! being tracked upstream.  This module provides the rebalancer side so
//! that once mistral.rs adds hot-reload support, integration is a one-liner.

use std::sync::Arc;

use tokio::sync::{broadcast, Mutex};
use tracing::{info, warn};

use memory_arbiter::{
    arbiter::MemoryArbiter,
    model_profile::ModelProfile,
    plan::AllocationPlan,
    pressure::PressureEvent,
    traits::DynamicDeviceMap,
};

/// Configuration for the live rebalancer.
#[derive(Debug, Clone)]
pub struct RebalancerConfig {
    /// Only rebalance if the GPU layer count would change by at least this
    /// amount.  Prevents thrashing on minor fluctuations.
    /// Default: 2.
    pub min_layer_delta: usize,

    /// Rebalance when a `VramLow` event is received.  Default: true.
    pub rebalance_on_vram_low: bool,

    /// Rebalance when a `VramCritical` event is received.  Default: true.
    pub rebalance_on_vram_critical: bool,

    /// Rebalance when pressure is relieved (load more layers back to GPU).
    /// Default: true.
    pub rebalance_on_pressure_relief: bool,
}

impl Default for RebalancerConfig {
    fn default() -> Self {
        Self {
            min_layer_delta: 2,
            rebalance_on_vram_low: true,
            rebalance_on_vram_critical: true,
            rebalance_on_pressure_relief: true,
        }
    }
}

/// Watches pressure events and pushes updated plans to a [`DynamicDeviceMap`].
pub struct LiveRebalancer {
    _task: tokio::task::JoinHandle<()>,
}

impl LiveRebalancer {
    /// Start the live rebalancer.
    ///
    /// * `pressure_rx` — subscribe handle from a [`PressureMonitor`].
    /// * `model` — the model whose allocation should be rebalanced.
    /// * `target` — the runtime to push updated plans to.
    /// * `config` — rebalancer configuration.
    pub fn start(
        mut pressure_rx: broadcast::Receiver<PressureEvent>,
        model: ModelProfile,
        target: Arc<Mutex<dyn DynamicDeviceMap>>,
        config: RebalancerConfig,
    ) -> Self {
        let task = tokio::spawn(async move {
            let mut arbiter = MemoryArbiter::with_defaults();
            let mut last_gpu_layers: Option<usize> = None;

            while let Ok(event) = pressure_rx.recv().await {
                let should_rebalance = match &event {
                    PressureEvent::VramCritical { .. } => config.rebalance_on_vram_critical,
                    PressureEvent::VramLow { .. } => config.rebalance_on_vram_low,
                    PressureEvent::PressureRelieved => config.rebalance_on_pressure_relief,
                    PressureEvent::ProbeSnapshot(_) | PressureEvent::RamLow { .. } => false,
                };

                if !should_rebalance {
                    continue;
                }

                info!(
                    target: "mistralrs_bridge::rebalancer",
                    ?event,
                    "Pressure event received — computing new plan"
                );

                let plan = match arbiter.plan(&model) {
                    Ok(p) => p,
                    Err(e) => {
                        warn!("LiveRebalancer: arbiter.plan failed: {e}");
                        continue;
                    }
                };

                // Only apply if the layer delta is significant.
                if let Some(prev) = last_gpu_layers {
                    let delta = (plan.gpu_layer_count as isize - prev as isize).unsigned_abs();
                    if delta < config.min_layer_delta {
                        info!(
                            delta,
                            threshold = config.min_layer_delta,
                            "Layer delta below threshold; skipping rebalance"
                        );
                        continue;
                    }
                }

                let mut t = target.lock().await;
                if !t.can_rebalance() {
                    info!("DynamicDeviceMap declined rebalance (busy)");
                    continue;
                }

                match t.apply_plan(&plan) {
                    Ok(()) => {
                        info!(
                            gpu_layers = plan.gpu_layer_count,
                            cpu_layers = plan.cpu_layer_count,
                            "LiveRebalancer: plan applied"
                        );
                        last_gpu_layers = Some(plan.gpu_layer_count);
                    }
                    Err(e) => {
                        warn!("LiveRebalancer: apply_plan failed: {e}");
                    }
                }
            }
        });

        Self { _task: task }
    }
}
