//! # mistralrs-bridge
//!
//! Integration layer between [`memory_arbiter`] and `mistral.rs`.
//!
//! ## What this crate does
//!
//! `mistral.rs` exposes a `DeviceMapMetadata` struct that controls which
//! transformer layers are placed on which CUDA device.  At present this
//! metadata is set once at model-load time and cannot be updated while the
//! model is running.  This bridge crate provides:
//!
//! * [`MistralrsDeviceMap`] — a [`DynamicDeviceMap`] implementation that
//!   converts an [`AllocationPlan`] into the `DeviceMapMetadata` format
//!   mistral.rs expects.
//! * [`ArbiterPipelineBuilder`] — a high-level builder that probes hardware,
//!   computes an optimal plan, and produces the CLI flags / config struct
//!   needed to launch mistral.rs with correct offloading.
//! * [`LiveRebalancer`] — a Tokio task wrapper that watches [`PressureEvent`]s
//!   and triggers a re-plan when memory pressure changes.  Requires the
//!   in-progress mistral.rs hot-reload API (tracked in
//!   <https://github.com/EricLBuehler/mistral.rs/issues/XXX>).
//!
//! ## Contribution notes
//!
//! The types in this crate are designed so that `MistralrsDeviceMap` and
//! `ArbiterPipelineBuilder` can be merged directly into mistral.rs's
//! `mistralrs` crate once the upstream team is ready to accept dynamic
//! device mapping.

#![warn(missing_docs, rust_2018_idioms)]

pub mod builder;
pub mod device_map;
pub mod live_rebalancer;
pub mod model_profile_ext;

pub use builder::ArbiterPipelineBuilder;
pub use device_map::MistralrsDeviceMap;
pub use live_rebalancer::LiveRebalancer;
pub use model_profile_ext::ModelProfileExt;
