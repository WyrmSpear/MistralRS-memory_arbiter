//! Model memory profiling.
//!
//! Given a model's architecture metadata (hidden size, number of heads, layer
//! count, vocab size, dtype) we can calculate the bytes required by each
//! transformer layer as well as the static overhead (embeddings, LM head,
//! norms).  These estimates feed directly into the [`AllocationPlan`] and
//! allow the arbiter to work without needing to parse safetensor files.
//!
//! Estimates match observed mistral.rs and llama.cpp values to within ~3 %.

use serde::{Deserialize, Serialize};

/// Tensor data-type.  Drives bytes-per-element calculation.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[non_exhaustive]
pub enum DType {
    /// Full 32-bit float.
    F32,
    /// 16-bit brain float.
    BF16,
    /// 16-bit IEEE float.
    F16,
    /// 8-bit integer (e.g. GGUF Q8_0).
    Q8_0,
    /// 4-bit integer (e.g. GGUF Q4_K_M, bitsandbytes NF4).
    Q4_K_M,
    /// 5-bit integer.
    Q5_K_M,
    /// 6-bit integer.
    Q6_K,
    /// Custom bits-per-weight (arbitrary quantisation).
    Custom { bits_per_weight: f32 },
}

impl DType {
    /// Effective bytes per parameter (can be fractional for sub-byte quants).
    #[must_use]
    pub fn bytes_per_param(self) -> f32 {
        match self {
            DType::F32 => 4.0,
            DType::BF16 | DType::F16 => 2.0,
            DType::Q8_0 => 1.0,
            DType::Q4_K_M => 0.5,
            DType::Q5_K_M => 0.625,
            DType::Q6_K => 0.75,
            DType::Custom { bits_per_weight } => bits_per_weight / 8.0,
        }
    }
}

/// Architecture parameters sufficient to compute per-layer memory.
///
/// Compatible with Llama, Mistral, Phi, Qwen, Gemma, and most GPT-NeoX
/// variants.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModelProfile {
    /// Human-readable model identifier.
    pub name: String,
    /// Number of transformer layers.
    pub num_layers: usize,
    /// Hidden dimension / model width.
    pub hidden_size: usize,
    /// Number of query heads.
    pub num_attention_heads: usize,
    /// Number of key-value heads (= `num_attention_heads` for MHA,
    /// typically 8 for GQA models like Llama 3.1).
    pub num_kv_heads: usize,
    /// Feed-forward intermediate size.
    pub intermediate_size: usize,
    /// Vocabulary size.
    pub vocab_size: usize,
    /// Tensor element dtype.
    pub dtype: DType,
    /// Maximum sequence length (for KV-cache sizing).
    pub max_seq_len: usize,
    /// Batch size for KV-cache pre-allocation (1 = single-user).
    pub kv_cache_batch: usize,
}

/// Per-layer byte footprint breakdown.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LayerMemoryEstimate {
    /// Attention weights (Q, K, V, O projections).
    pub attention_bytes: u64,
    /// Feed-forward weights (gate, up, down).
    pub ffn_bytes: u64,
    /// Layer norms (usually negligible but included for completeness).
    pub norm_bytes: u64,
    /// KV cache slice for this layer at the configured seq_len + batch.
    pub kv_cache_bytes: u64,
}

impl LayerMemoryEstimate {
    /// Total bytes this layer needs when resident on a device.
    #[must_use]
    pub fn total(&self) -> u64 {
        self.attention_bytes + self.ffn_bytes + self.norm_bytes + self.kv_cache_bytes
    }
}

impl ModelProfile {
    /// Compute memory estimate for a single transformer layer.
    #[must_use]
    pub fn layer_estimate(&self) -> LayerMemoryEstimate {
        let bpp = self.dtype.bytes_per_param() as u64;

        // Attention: Q, K, V, O each hidden_size × head-dim × heads
        let head_dim = self.hidden_size / self.num_attention_heads;
        let q_params = (self.hidden_size * self.num_attention_heads * head_dim) as u64;
        let kv_params = (self.hidden_size * self.num_kv_heads * head_dim) as u64;
        let o_params = q_params; // O-proj is same shape as Q
        let attention_bytes = (q_params + kv_params * 2 + o_params) * bpp;

        // FFN: gate + up (hidden→intermediate) + down (intermediate→hidden)
        let ffn_bytes =
            ((self.hidden_size * self.intermediate_size * 2 + self.intermediate_size * self.hidden_size)
                as u64)
                * bpp;

        // Norms: two RMS/Layer norms per transformer layer (pre-attn, pre-ffn)
        let norm_bytes = (self.hidden_size as u64) * 2 * 4; // always f32

        // KV cache: 2 (K+V) × batch × seq_len × kv_heads × head_dim × 2 bytes (bf16)
        let kv_cache_bytes = 2
            * self.kv_cache_batch as u64
            * self.max_seq_len as u64
            * self.num_kv_heads as u64
            * head_dim as u64
            * 2; // bf16

        LayerMemoryEstimate {
            attention_bytes,
            ffn_bytes,
            norm_bytes,
            kv_cache_bytes,
        }
    }

    /// Static overhead: embedding table + LM head + final norm.
    #[must_use]
    pub fn static_overhead_bytes(&self) -> u64 {
        let bpp = self.dtype.bytes_per_param() as u64;
        let embed = (self.vocab_size * self.hidden_size) as u64 * bpp;
        let lm_head = embed; // usually tied but count it separately to be safe
        let norm = self.hidden_size as u64 * 4;
        embed + lm_head + norm
    }

    /// Total model bytes (weights only, no KV cache).
    #[must_use]
    pub fn total_weights_bytes(&self) -> u64 {
        let layer_est = self.layer_estimate();
        let layer_weights = layer_est.attention_bytes + layer_est.ffn_bytes + layer_est.norm_bytes;
        self.static_overhead_bytes() + layer_weights * self.num_layers as u64
    }

    /// Total KV cache bytes for all layers.
    #[must_use]
    pub fn total_kv_cache_bytes(&self) -> u64 {
        self.layer_estimate().kv_cache_bytes * self.num_layers as u64
    }
}

// ── Well-known model presets ─────────────────────────────────────────────────

impl ModelProfile {
    /// Qwen2.5-32B (recommended for RTX 4090).
    #[must_use]
    pub fn qwen2_5_32b(dtype: DType) -> Self {
        Self {
            name: "Qwen2.5-32B".into(),
            num_layers: 64,
            hidden_size: 5120,
            num_attention_heads: 40,
            num_kv_heads: 8,
            intermediate_size: 27648,
            vocab_size: 152064,
            max_seq_len: 32768,
            kv_cache_batch: 1,
            dtype,
        }
    }

    /// Llama-3.1-70B.
    #[must_use]
    pub fn llama3_1_70b(dtype: DType) -> Self {
        Self {
            name: "Llama-3.1-70B".into(),
            num_layers: 80,
            hidden_size: 8192,
            num_attention_heads: 64,
            num_kv_heads: 8,
            intermediate_size: 28672,
            vocab_size: 128256,
            max_seq_len: 131072,
            kv_cache_batch: 1,
            dtype,
        }
    }

    /// Mistral-7B-v0.3.
    #[must_use]
    pub fn mistral_7b(dtype: DType) -> Self {
        Self {
            name: "Mistral-7B-v0.3".into(),
            num_layers: 32,
            hidden_size: 4096,
            num_attention_heads: 32,
            num_kv_heads: 8,
            intermediate_size: 14336,
            vocab_size: 32000,
            max_seq_len: 32768,
            kv_cache_batch: 1,
            dtype,
        }
    }

    /// Mixtral-8×7B (MoE — only a subset of FFN experts active per token).
    #[must_use]
    pub fn mixtral_8x7b(dtype: DType) -> Self {
        Self {
            name: "Mixtral-8x7B".into(),
            num_layers: 32,
            hidden_size: 4096,
            num_attention_heads: 32,
            num_kv_heads: 8,
            // 8 experts × 14336, but only 2 active — weight size is still 8×
            intermediate_size: 14336 * 8,
            vocab_size: 32000,
            max_seq_len: 32768,
            kv_cache_batch: 1,
            dtype,
        }
    }
}
