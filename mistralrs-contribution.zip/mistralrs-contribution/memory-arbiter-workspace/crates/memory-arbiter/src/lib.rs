//! # memory-arbiter
//!
//! Dynamic RAM/VRAM layer-offload arbiter for transformer inference.
//!
//! ## Problem
//! `mistral.rs` (and most Rust inference runtimes) use a *static*
//! `DeviceMapMetadata` that must be set before loading a model.  Ollama
//! sidesteps this by probing available memory at load time and continuously
//! adjusting how many transformer layers live on the GPU vs the CPU.  Under
//! memory pressure Ollama gracefully degrades rather than OOM-panicking.
//!
//! ## What this crate provides
//! 1. **[`HardwareProbe`]** — snapshot of available VRAM (per-device) and
//!    system RAM, updated on demand or by a background task.
//! 2. **[`ModelProfile`]** — per-layer memory footprint estimates derived
//!    from architecture metadata (head count, hidden size, dtype).
//! 3. **[`AllocationPlan`]** — the computed layer→device assignment with
//!    headroom margins and eviction hints.
//! 4. **[`MemoryArbiter`]** — the engine that owns a `HardwareProbe`,
//!    accepts a `ModelProfile`, and emits `AllocationPlan`s.
//! 5. **[`DynamicDeviceMap`]** — trait that mistral.rs (or any runtime) can
//!    implement so the arbiter can push live rebalance events.
//! 6. **[`PressureMonitor`]** — optional Tokio task that polls hardware and
//!    fires callbacks when thresholds are breached.

#![warn(missing_docs, rust_2018_idioms, clippy::pedantic)]

pub mod arbiter;
pub mod hardware;
pub mod model_profile;
pub mod plan;
pub mod pressure;
pub mod traits;

// Re-export the most-used public surface.
pub use arbiter::MemoryArbiter;
pub use hardware::{DeviceMemory, GpuDevice, HardwareProbe};
pub use model_profile::{DType, LayerMemoryEstimate, ModelProfile};
pub use plan::{AllocationPlan, DeviceAssignment, LayerAssignment};
pub use pressure::{PressureEvent, PressureMonitor, PressureThresholds};
pub use traits::DynamicDeviceMap;
