//! Traits for runtime integration.
//!
//! Any inference engine that wants live rebalancing from the arbiter
//! implements [`DynamicDeviceMap`].  The trait is intentionally minimal
//! so it can be adopted upstream by mistral.rs without forcing heavy
//! refactors.

use crate::plan::AllocationPlan;

/// A callback-style interface for inference runtimes.
///
/// Implement this on whatever type owns your loaded model tensors.
/// The arbiter will call [`apply_plan`](DynamicDeviceMap::apply_plan)
/// whenever a better allocation is computed.
///
/// # Relationship to `mistral.rs` internals
/// In mistral.rs this would be implemented on the `Pipeline` struct (or a
/// wrapper).  The implementation only needs to call the existing
/// `get_device_map` / set methods or trigger a model-tensor migration.
///
/// A no-op implementation is provided via [`NullDeviceMap`] for testing.
pub trait DynamicDeviceMap: Send + Sync {
    /// Apply a newly computed allocation plan.
    ///
    /// Called by the arbiter when the plan changes.  Implementations
    /// should move tensors between devices as needed.  This operation
    /// is allowed to be async in your runtime; the trait uses a
    /// synchronous signature so it can be object-safe.  Wrap in a
    /// `tokio::spawn` internally if you need async.
    ///
    /// # Errors
    /// Return an `Err` string if migration fails.  The arbiter will
    /// log the error and retain the previous plan.
    fn apply_plan(&mut self, plan: &AllocationPlan) -> Result<(), String>;

    /// Optional: return the plan currently in effect.
    fn current_plan(&self) -> Option<&AllocationPlan> {
        None
    }

    /// Optional: hint that a rebalance *might* be beneficial.
    /// The arbiter calls this before computing a new plan; return
    /// `false` to suppress the rebalance (e.g. model is mid-generation).
    fn can_rebalance(&self) -> bool {
        true
    }
}

/// A no-op implementation of [`DynamicDeviceMap`] for tests and
/// environments where tensor migration is not needed.
#[derive(Debug, Default)]
pub struct NullDeviceMap {
    plan: Option<AllocationPlan>,
}

impl DynamicDeviceMap for NullDeviceMap {
    fn apply_plan(&mut self, plan: &AllocationPlan) -> Result<(), String> {
        tracing::info!(
            gpu_layers = plan.gpu_layer_count,
            cpu_layers = plan.cpu_layer_count,
            model = %plan.model_name,
            "NullDeviceMap: received plan (no-op)"
        );
        self.plan = Some(plan.clone());
        Ok(())
    }

    fn current_plan(&self) -> Option<&AllocationPlan> {
        self.plan.as_ref()
    }
}

/// A logging-only implementation that prints plans without moving tensors.
/// Useful when integrating with an existing runtime incrementally.
#[derive(Debug, Default)]
pub struct LoggingDeviceMap {
    plan: Option<AllocationPlan>,
}

impl DynamicDeviceMap for LoggingDeviceMap {
    fn apply_plan(&mut self, plan: &AllocationPlan) -> Result<(), String> {
        tracing::warn!(
            target: "memory_arbiter::device_map",
            "{}",
            plan
        );
        self.plan = Some(plan.clone());
        Ok(())
    }

    fn current_plan(&self) -> Option<&AllocationPlan> {
        self.plan.as_ref()
    }
}
