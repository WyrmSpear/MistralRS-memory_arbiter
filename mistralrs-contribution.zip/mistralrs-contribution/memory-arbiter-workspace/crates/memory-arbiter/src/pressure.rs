//! Background memory pressure monitoring.
//!
//! [`PressureMonitor`] spawns a Tokio task that periodically re-probes
//! hardware and fires [`PressureEvent`] callbacks when configurable
//! thresholds are breached.  This is how the arbiter achieves Ollama-style
//! *dynamic* rebalancing rather than one-shot load-time allocation.

use std::sync::Arc;
use std::time::Duration;

use tokio::sync::{broadcast, Mutex};
use tokio::time;
use tracing::{debug, info, warn};

use crate::hardware::HardwareProbe;

/// A pressure threshold configuration.
#[derive(Debug, Clone)]
pub struct PressureThresholds {
    /// Fire [`PressureEvent::VramLow`] when any GPU's free VRAM falls
    /// below this fraction.  Default: 0.15 (15 %).
    pub vram_low_fraction: f64,

    /// Fire [`PressureEvent::VramCritical`] below this fraction.
    /// Default: 0.05 (5 %).
    pub vram_critical_fraction: f64,

    /// Fire [`PressureEvent::RamLow`] when system free RAM falls below
    /// this fraction of total.  Default: 0.20 (20 %).
    pub ram_low_fraction: f64,

    /// How often to re-probe hardware.  Default: 5 seconds.
    pub poll_interval: Duration,
}

impl Default for PressureThresholds {
    fn default() -> Self {
        Self {
            vram_low_fraction: 0.15,
            vram_critical_fraction: 0.05,
            ram_low_fraction: 0.20,
            poll_interval: Duration::from_secs(5),
        }
    }
}

/// An event emitted by the pressure monitor.
#[derive(Debug, Clone)]
pub enum PressureEvent {
    /// GPU `gpu_index` has low VRAM.
    VramLow { gpu_index: u32, free_fraction: f64 },
    /// GPU `gpu_index` has critically low VRAM — consider evicting layers now.
    VramCritical { gpu_index: u32, free_fraction: f64 },
    /// System RAM is running low.
    RamLow { free_fraction: f64 },
    /// Pressure has returned to normal after a previous event.
    PressureRelieved,
    /// A fresh hardware probe snapshot.
    ProbeSnapshot(HardwareProbe),
}

/// Spawns a background Tokio task that monitors memory pressure.
///
/// # Usage
/// ```rust,no_run
/// use memory_arbiter::pressure::{PressureMonitor, PressureThresholds};
///
/// #[tokio::main]
/// async fn main() {
///     let monitor = PressureMonitor::start(PressureThresholds::default());
///     let mut rx = monitor.subscribe();
///     while let Ok(event) = rx.recv().await {
///         println!("{event:?}");
///     }
/// }
/// ```
pub struct PressureMonitor {
    sender: broadcast::Sender<PressureEvent>,
    _task: tokio::task::JoinHandle<()>,
}

impl PressureMonitor {
    /// Start the background monitor.
    #[must_use]
    pub fn start(thresholds: PressureThresholds) -> Self {
        let (tx, _rx) = broadcast::channel(64);
        let sender = tx.clone();

        let task = tokio::spawn(async move {
            let mut interval = time::interval(thresholds.poll_interval);
            let mut was_under_pressure = false;

            loop {
                interval.tick().await;

                let probe = match HardwareProbe::capture() {
                    Ok(p) => p,
                    Err(e) => {
                        warn!("PressureMonitor: probe failed: {e}");
                        continue;
                    }
                };

                let _ = tx.send(PressureEvent::ProbeSnapshot(probe.clone()));

                let mut under_pressure = false;

                for gpu in &probe.gpus {
                    let frac = gpu.memory.free as f64 / gpu.memory.total as f64;
                    if frac < thresholds.vram_critical_fraction {
                        under_pressure = true;
                        let _ = tx.send(PressureEvent::VramCritical {
                            gpu_index: gpu.index,
                            free_fraction: frac,
                        });
                        warn!(
                            gpu = gpu.index,
                            pct = format!("{:.1}", frac * 100.0),
                            "VRAM critically low"
                        );
                    } else if frac < thresholds.vram_low_fraction {
                        under_pressure = true;
                        let _ = tx.send(PressureEvent::VramLow {
                            gpu_index: gpu.index,
                            free_fraction: frac,
                        });
                        info!(
                            gpu = gpu.index,
                            pct = format!("{:.1}", frac * 100.0),
                            "VRAM low"
                        );
                    }
                }

                let ram_frac =
                    probe.system_ram.free as f64 / probe.system_ram.total as f64;
                if ram_frac < thresholds.ram_low_fraction {
                    under_pressure = true;
                    let _ = tx.send(PressureEvent::RamLow {
                        free_fraction: ram_frac,
                    });
                    warn!(pct = format!("{:.1}", ram_frac * 100.0), "System RAM low");
                }

                if was_under_pressure && !under_pressure {
                    let _ = tx.send(PressureEvent::PressureRelieved);
                    info!("Memory pressure relieved");
                }
                was_under_pressure = under_pressure;

                debug!("PressureMonitor tick complete");
            }
        });

        Self {
            sender,
            _task: task,
        }
    }

    /// Subscribe to pressure events.
    #[must_use]
    pub fn subscribe(&self) -> broadcast::Receiver<PressureEvent> {
        self.sender.subscribe()
    }
}
