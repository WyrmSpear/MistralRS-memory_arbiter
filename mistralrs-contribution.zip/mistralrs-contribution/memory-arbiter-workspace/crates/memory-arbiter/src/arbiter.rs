//! The [`MemoryArbiter`] — the core allocation engine.
//!
//! The arbiter replicates (and generalises) the logic Ollama uses to decide
//! how many transformer layers to place on the GPU vs. CPU:
//!
//! 1. Probe available VRAM and system RAM.
//! 2. Compute per-layer byte cost from the `ModelProfile`.
//! 3. Greedily fill GPU device(s) with as many layers as will fit,
//!    respecting the safety margin.
//! 4. Spill remaining layers to CPU RAM.
//! 5. Emit an `AllocationPlan` that any `DynamicDeviceMap` can consume.
//!
//! The arbiter also supports **multi-GPU** spreading, **priority layers**
//! (force early/late layers to specific devices), and a **dry-run** mode
//! for benchmarking without touching tensors.

use std::collections::HashMap;

use tracing::{debug, info, warn};

use crate::{
    hardware::HardwareProbe,
    model_profile::ModelProfile,
    plan::{AllocationPlan, DeviceAssignment, DeviceUtilisation, LayerAssignment},
    traits::DynamicDeviceMap,
};

/// Configuration for the arbiter.
#[derive(Debug, Clone)]
pub struct ArbiterConfig {
    /// Fraction of free VRAM to keep unallocated as a safety buffer.
    /// Default: 0.10 (10 %).
    pub vram_safety_margin: f64,

    /// Fraction of free system RAM to keep unallocated.
    /// Default: 0.15 (15 %).
    pub ram_safety_margin: f64,

    /// If true, place static weights (embeddings) on GPU when there is
    /// sufficient VRAM after layers are allocated.
    /// Default: true.
    pub prefer_gpu_static_weights: bool,

    /// If true, place the KV cache on GPU alongside its layer.
    /// Set to false to reclaim VRAM at the cost of PCIe bandwidth.
    /// Default: true.
    pub kv_cache_on_gpu: bool,

    /// Strategy for distributing layers across multiple GPUs.
    pub multi_gpu_strategy: MultiGpuStrategy,

    /// Minimum number of layers that must be on GPU before any GPU is used.
    /// Prevents the pathological case where 1 layer on GPU + rest on CPU is
    /// slower than all-CPU due to PCIe overhead.
    /// Default: 4.
    pub min_gpu_layer_threshold: usize,
}

impl Default for ArbiterConfig {
    fn default() -> Self {
        Self {
            vram_safety_margin: 0.10,
            ram_safety_margin: 0.15,
            prefer_gpu_static_weights: true,
            kv_cache_on_gpu: true,
            multi_gpu_strategy: MultiGpuStrategy::Sequential,
            min_gpu_layer_threshold: 4,
        }
    }
}

/// How to distribute layers when multiple GPUs are present.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MultiGpuStrategy {
    /// Fill GPU 0 first, then GPU 1, etc.  Simple and predictable.
    Sequential,
    /// Distribute layers proportionally to each GPU's free VRAM.
    Proportional,
}

/// The main arbiter struct.
pub struct MemoryArbiter {
    config: ArbiterConfig,
    last_probe: Option<HardwareProbe>,
}

impl MemoryArbiter {
    /// Create a new arbiter with the given configuration.
    #[must_use]
    pub fn new(config: ArbiterConfig) -> Self {
        Self {
            config,
            last_probe: None,
        }
    }

    /// Create with default configuration.
    #[must_use]
    pub fn with_defaults() -> Self {
        Self::new(ArbiterConfig::default())
    }

    /// Probe hardware and compute an `AllocationPlan` for the given model.
    ///
    /// This is the primary entry point.
    ///
    /// # Errors
    /// Returns an error string if hardware probing fails.
    pub fn plan(&mut self, model: &ModelProfile) -> Result<AllocationPlan, String> {
        let probe = HardwareProbe::capture().map_err(|e| e.to_string())?;
        info!(target: "memory_arbiter", "{}", probe);
        let plan = self.compute_plan(model, &probe);
        self.last_probe = Some(probe);
        Ok(plan)
    }

    /// Compute a plan from an already-captured probe (useful for testing).
    #[must_use]
    pub fn plan_with_probe(&self, model: &ModelProfile, probe: &HardwareProbe) -> AllocationPlan {
        self.compute_plan(model, probe)
    }

    /// Apply a freshly computed plan to a runtime.
    ///
    /// # Errors
    /// Propagates any error from `DynamicDeviceMap::apply_plan`.
    pub fn plan_and_apply(
        &mut self,
        model: &ModelProfile,
        target: &mut dyn DynamicDeviceMap,
    ) -> Result<AllocationPlan, String> {
        if !target.can_rebalance() {
            warn!("DynamicDeviceMap reported can_rebalance=false; skipping");
            return Err("target declined rebalance".into());
        }
        let plan = self.plan(model)?;
        target.apply_plan(&plan)?;
        Ok(plan)
    }

    // ── Core allocation algorithm ─────────────────────────────────────────

    fn compute_plan(&self, model: &ModelProfile, probe: &HardwareProbe) -> AllocationPlan {
        let layer_est = model.layer_estimate();
        let layer_bytes_weights =
            layer_est.attention_bytes + layer_est.ffn_bytes + layer_est.norm_bytes;
        let layer_bytes_kv = layer_est.kv_cache_bytes;

        let layer_bytes_gpu = if self.config.kv_cache_on_gpu {
            layer_bytes_weights + layer_bytes_kv
        } else {
            layer_bytes_weights
        };

        debug!(
            model = %model.name,
            layer_weights_gib = layer_bytes_weights as f64 / (1 << 30) as f64,
            layer_kv_gib = layer_bytes_kv as f64 / (1 << 30) as f64,
            "per-layer cost"
        );

        // Build per-GPU budgets.
        let gpu_budgets: Vec<u64> = probe
            .gpus
            .iter()
            .map(|g| g.memory.available_with_margin(self.config.vram_safety_margin))
            .collect();

        let total_gpu_budget: u64 = gpu_budgets.iter().sum();

        // Determine how many layers fit on GPU(s).
        let max_gpu_layers = if layer_bytes_gpu == 0 || total_gpu_budget == 0 {
            0
        } else {
            (total_gpu_budget / layer_bytes_gpu) as usize
        };

        let gpu_layers = max_gpu_layers.min(model.num_layers);

        // Apply minimum threshold — don't bother using GPU if too few layers fit.
        let gpu_layers = if gpu_layers < self.config.min_gpu_layer_threshold {
            info!(
                gpu_layers,
                threshold = self.config.min_gpu_layer_threshold,
                "GPU layer count below threshold — falling back to all-CPU"
            );
            0
        } else {
            gpu_layers
        };

        let cpu_layers = model.num_layers - gpu_layers;

        // Build layer assignments.
        let mut layers = Vec::with_capacity(model.num_layers);
        let mut gpu_remaining: Vec<u64> = gpu_budgets.clone();

        for i in 0..model.num_layers {
            let (weights_device, kv_device) = if i < gpu_layers {
                let gpu_idx = self.select_gpu_for_layer(i, &gpu_remaining, layer_bytes_gpu);
                if let Some(gidx) = gpu_idx {
                    // Deduct from budget.
                    if gpu_remaining[gidx as usize] >= layer_bytes_gpu {
                        gpu_remaining[gidx as usize] -= layer_bytes_gpu;
                    }
                    let gpu = DeviceAssignment::Gpu(gidx);
                    let kv = if self.config.kv_cache_on_gpu {
                        gpu.clone()
                    } else {
                        DeviceAssignment::Cpu
                    };
                    (gpu, kv)
                } else {
                    // GPU budget exhausted mid-plan — spill to CPU.
                    (DeviceAssignment::Cpu, DeviceAssignment::Cpu)
                }
            } else {
                (DeviceAssignment::Cpu, DeviceAssignment::Cpu)
            };

            layers.push(LayerAssignment {
                layer_idx: i,
                weight_bytes: layer_bytes_weights,
                kv_cache_bytes: layer_bytes_kv,
                weights_device,
                kv_cache_device: kv_device,
            });
        }

        // Static weights placement.
        let static_bytes = model.static_overhead_bytes();
        let static_device = if self.config.prefer_gpu_static_weights
            && probe.gpus.first().map_or(0, |g| {
                g.memory.available_with_margin(self.config.vram_safety_margin)
            }) >= static_bytes
                + gpu_layers as u64 * layer_bytes_gpu
        {
            DeviceAssignment::Gpu(0)
        } else {
            DeviceAssignment::Cpu
        };

        // Build utilisation map.
        let mut device_utilisation: HashMap<String, DeviceUtilisation> = HashMap::new();

        for layer in &layers {
            let key = match &layer.weights_device {
                DeviceAssignment::Gpu(i) => format!("GPU:{i}"),
                DeviceAssignment::Cpu => "CPU".to_string(),
            };
            let entry = device_utilisation.entry(key).or_default();
            entry.assigned_bytes += layer.weight_bytes;
            entry.layer_count += 1;
        }

        // Set free_bytes_at_plan_time.
        for (key, util) in &mut device_utilisation {
            if key.starts_with("GPU:") {
                let idx: usize = key.trim_start_matches("GPU:").parse().unwrap_or(0);
                util.free_bytes_at_plan_time =
                    probe.gpus.get(idx).map_or(0, |g| g.memory.free);
            } else {
                util.free_bytes_at_plan_time = probe.system_ram.free;
            }
        }

        let spill_reason = if cpu_layers > 0 {
            Some(format!(
                "{cpu_layers} layer(s) spilled to CPU — insufficient VRAM \
                 (needed {needed:.2} GiB, available {avail:.2} GiB after {margin:.0}% margin)",
                needed = model.num_layers as f64 * layer_bytes_gpu as f64 / (1 << 30) as f64,
                avail = total_gpu_budget as f64 / (1 << 30) as f64,
                margin = self.config.vram_safety_margin * 100.0,
            ))
        } else {
            None
        };

        if let Some(ref reason) = spill_reason {
            info!(target: "memory_arbiter", "{reason}");
        }

        AllocationPlan {
            model_name: model.name.clone(),
            layers,
            static_weights_device: static_device,
            device_utilisation,
            gpu_layer_count: gpu_layers,
            cpu_layer_count: cpu_layers,
            spill_reason,
            vram_safety_margin: self.config.vram_safety_margin,
        }
    }

    /// Choose which GPU to place a layer on.
    fn select_gpu_for_layer(
        &self,
        layer_idx: usize,
        gpu_remaining: &[u64],
        layer_cost: u64,
    ) -> Option<u32> {
        match self.config.multi_gpu_strategy {
            MultiGpuStrategy::Sequential => {
                // Fill GPU 0, then GPU 1, etc.
                for (i, &budget) in gpu_remaining.iter().enumerate() {
                    if budget >= layer_cost {
                        return Some(i as u32);
                    }
                }
                None
            }
            MultiGpuStrategy::Proportional => {
                // Place on the GPU with the most remaining budget.
                gpu_remaining
                    .iter()
                    .enumerate()
                    .filter(|(_, &b)| b >= layer_cost)
                    .max_by_key(|(_, &b)| b)
                    .map(|(i, _)| i as u32)
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model_profile::{DType, ModelProfile};

    fn mock_probe_24gib() -> HardwareProbe {
        use crate::hardware::{DeviceMemory, GpuDevice};
        const GIB: u64 = 1 << 30;
        HardwareProbe {
            gpus: vec![GpuDevice {
                index: 0,
                name: "Mock RTX 4090".into(),
                memory: DeviceMemory {
                    total: 24 * GIB,
                    free: 22 * GIB,
                    process_used: 2 * GIB,
                },
                pci_bus_id: None,
            }],
            system_ram: DeviceMemory {
                total: 128 * GIB,
                free: 96 * GIB,
                process_used: 32 * GIB,
            },
        }
    }

    #[test]
    fn mistral_7b_fits_on_4090_q4() {
        let arbiter = MemoryArbiter::with_defaults();
        let model = ModelProfile::mistral_7b(DType::Q4_K_M);
        let probe = mock_probe_24gib();
        let plan = arbiter.plan_with_probe(&model, &probe);
        // A Q4 7B model should fit entirely on a 24 GiB GPU.
        assert_eq!(plan.cpu_layer_count, 0, "Expected all layers on GPU");
        assert!(plan.is_fully_gpu());
    }

    #[test]
    fn qwen_32b_partial_offload_q4() {
        let arbiter = MemoryArbiter::with_defaults();
        let model = ModelProfile::qwen2_5_32b(DType::Q4_K_M);
        let probe = mock_probe_24gib();
        let plan = arbiter.plan_with_probe(&model, &probe);
        // Q4 32B model: ~18–20 GiB.  Should mostly fit.
        println!("{plan}");
        assert!(plan.gpu_layer_count > 0);
    }

    #[test]
    fn llama_70b_spills_to_cpu_q4() {
        let arbiter = MemoryArbiter::with_defaults();
        let model = ModelProfile::llama3_1_70b(DType::Q4_K_M);
        let probe = mock_probe_24gib();
        let plan = arbiter.plan_with_probe(&model, &probe);
        // Q4 70B ~ 37 GiB: must spill to CPU on a 24 GiB card.
        assert!(plan.cpu_layer_count > 0, "Expected CPU spill for 70B on 24 GiB");
        assert!(plan.spill_reason.is_some());
        println!("{plan}");
    }

    #[test]
    fn device_map_string_is_valid() {
        let arbiter = MemoryArbiter::with_defaults();
        let model = ModelProfile::mistral_7b(DType::Q4_K_M);
        let probe = mock_probe_24gib();
        let plan = arbiter.plan_with_probe(&model, &probe);
        let s = plan.to_mistralrs_device_map_string();
        assert!(!s.is_empty());
        assert!(s.contains(':'));
        println!("device_map = {s}");
    }

    #[test]
    fn min_gpu_threshold_prevents_partial_gpu() {
        // Simulate very little VRAM — only 3 layers would fit.
        use crate::hardware::{DeviceMemory, GpuDevice};
        const GIB: u64 = 1 << 30;
        let tiny_probe = HardwareProbe {
            gpus: vec![GpuDevice {
                index: 0,
                name: "Tiny GPU".into(),
                memory: DeviceMemory {
                    total: 4 * GIB,
                    free: 3 * GIB,
                    process_used: GIB,
                },
                pci_bus_id: None,
            }],
            system_ram: DeviceMemory {
                total: 128 * GIB,
                free: 96 * GIB,
                process_used: 32 * GIB,
            },
        };
        let mut cfg = ArbiterConfig::default();
        cfg.min_gpu_layer_threshold = 4; // Default
        let arbiter = MemoryArbiter::new(cfg);
        let model = ModelProfile::llama3_1_70b(DType::Q4_K_M);
        let plan = arbiter.plan_with_probe(&model, &tiny_probe);
        // Should fall back to all-CPU rather than placing 3 layers on GPU.
        assert_eq!(plan.gpu_layer_count, 0, "Below threshold, should be all-CPU");
    }

    #[test]
    fn serialise_roundtrip() {
        let arbiter = MemoryArbiter::with_defaults();
        let model = ModelProfile::mistral_7b(DType::Q4_K_M);
        let probe = mock_probe_24gib();
        let plan = arbiter.plan_with_probe(&model, &probe);
        let json = plan.to_json().unwrap();
        let restored = AllocationPlan::from_json(&json).unwrap();
        assert_eq!(plan.gpu_layer_count, restored.gpu_layer_count);
    }
}
