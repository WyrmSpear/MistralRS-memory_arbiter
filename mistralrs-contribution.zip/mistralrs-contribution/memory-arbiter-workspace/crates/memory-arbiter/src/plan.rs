//! Allocation plan — the output of the arbiter.
//!
//! An [`AllocationPlan`] maps every transformer layer to a [`DeviceAssignment`]
//! and records the expected memory impact on each device.  It is the Rust
//! equivalent of Ollama's internal `numGPU` / `numCPU` split, but
//! generalised to multi-GPU and annotated with rich diagnostics.

use std::collections::HashMap;
use std::fmt;

use serde::{Deserialize, Serialize};

/// Where a layer (or the static overhead) should reside.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum DeviceAssignment {
    /// GPU device by zero-based index.
    Gpu(u32),
    /// Host CPU / system RAM.
    Cpu,
}

impl fmt::Display for DeviceAssignment {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            DeviceAssignment::Gpu(i) => write!(f, "GPU[{i}]"),
            DeviceAssignment::Cpu => write!(f, "CPU"),
        }
    }
}

/// Per-layer assignment record.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LayerAssignment {
    /// Zero-based layer index.
    pub layer_idx: usize,
    /// Where this layer's weights live.
    pub weights_device: DeviceAssignment,
    /// Where this layer's KV cache lives.
    /// Usually matches `weights_device`; can differ when VRAM is tight.
    pub kv_cache_device: DeviceAssignment,
    /// Bytes consumed on the weights device.
    pub weight_bytes: u64,
    /// Bytes consumed by KV cache on its device.
    pub kv_cache_bytes: u64,
}

/// Summary of device utilisation in a plan.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct DeviceUtilisation {
    /// Total bytes assigned to this device.
    pub assigned_bytes: u64,
    /// Free bytes that were available when the plan was computed.
    pub free_bytes_at_plan_time: u64,
    /// Number of transformer layers assigned.
    pub layer_count: usize,
}

impl DeviceUtilisation {
    /// Fractional utilisation (0.0 – 1.0).
    #[must_use]
    pub fn utilisation_fraction(&self) -> f64 {
        if self.free_bytes_at_plan_time == 0 {
            return 1.0;
        }
        self.assigned_bytes as f64 / self.free_bytes_at_plan_time as f64
    }
}

/// The complete allocation plan for a model on the current hardware.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AllocationPlan {
    /// Model identifier this plan was built for.
    pub model_name: String,

    /// Per-layer assignments, ordered by layer index.
    pub layers: Vec<LayerAssignment>,

    /// Where the static weights (embeddings, LM head, norms) live.
    pub static_weights_device: DeviceAssignment,

    /// Per-device utilisation summary.
    /// Keys: `"GPU:0"`, `"GPU:1"`, …, `"CPU"`.
    pub device_utilisation: HashMap<String, DeviceUtilisation>,

    /// Number of layers fully on GPU.
    pub gpu_layer_count: usize,

    /// Number of layers on CPU.
    pub cpu_layer_count: usize,

    /// Human-readable reason if any layers were spilled to CPU.
    pub spill_reason: Option<String>,

    /// Safety margin fraction used when computing this plan.
    pub vram_safety_margin: f64,
}

impl AllocationPlan {
    /// True when every transformer layer is on GPU (no CPU offloading).
    #[must_use]
    pub fn is_fully_gpu(&self) -> bool {
        self.cpu_layer_count == 0
    }

    /// Fraction of layers on GPU (0.0 – 1.0).
    #[must_use]
    pub fn gpu_fraction(&self) -> f64 {
        let total = self.gpu_layer_count + self.cpu_layer_count;
        if total == 0 {
            return 0.0;
        }
        self.gpu_layer_count as f64 / total as f64
    }

    /// Serialise to a pretty-printed JSON string (useful for persisting
    /// a pre-computed plan across restarts).
    ///
    /// # Errors
    /// Returns [`serde_json::Error`] if serialisation fails.
    pub fn to_json(&self) -> Result<String, serde_json::Error> {
        serde_json::to_string_pretty(self)
    }

    /// Deserialise from JSON.
    ///
    /// # Errors
    /// Returns [`serde_json::Error`] if deserialisation fails.
    pub fn from_json(json: &str) -> Result<Self, serde_json::Error> {
        serde_json::from_str(json)
    }

    /// Convert to a simple `(gpu_layers, total_layers)` tuple compatible
    /// with llama.cpp / Ollama's `--n-gpu-layers` flag.
    #[must_use]
    pub fn to_n_gpu_layers(&self) -> (usize, usize) {
        (self.gpu_layer_count, self.layers.len())
    }

    /// Build a `DeviceMapMetadata`-compatible string for mistral.rs.
    ///
    /// Format mirrors mistral.rs's `--device-map` CLI option:
    /// `"0:32,cpu:32"` meaning first 32 layers on GPU 0, next 32 on CPU.
    #[must_use]
    pub fn to_mistralrs_device_map_string(&self) -> String {
        // Group contiguous layers by device.
        let mut segments: Vec<(String, usize)> = Vec::new();

        for layer in &self.layers {
            let key = match &layer.weights_device {
                DeviceAssignment::Gpu(i) => i.to_string(),
                DeviceAssignment::Cpu => "cpu".to_string(),
            };
            if let Some(last) = segments.last_mut() {
                if last.0 == key {
                    last.1 += 1;
                    continue;
                }
            }
            segments.push((key, 1));
        }

        segments
            .iter()
            .map(|(dev, count)| format!("{dev}:{count}"))
            .collect::<Vec<_>>()
            .join(",")
    }
}

impl fmt::Display for AllocationPlan {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        writeln!(f, "=== AllocationPlan: {} ===", self.model_name)?;
        writeln!(
            f,
            "  GPU layers : {} / {}  ({:.1} %)",
            self.gpu_layer_count,
            self.layers.len(),
            self.gpu_fraction() * 100.0,
        )?;
        writeln!(f, "  CPU layers : {}", self.cpu_layer_count)?;
        writeln!(
            f,
            "  Static weights : {}",
            self.static_weights_device
        )?;
        writeln!(
            f,
            "  mistral.rs device-map : \"{}\"",
            self.to_mistralrs_device_map_string()
        )?;
        if let Some(ref reason) = self.spill_reason {
            writeln!(f, "  ⚠ Spill reason : {reason}")?;
        }
        for (dev, util) in &self.device_utilisation {
            writeln!(
                f,
                "  {dev:8}  assigned={:.2} GiB  utilisation={:.1} %  layers={}",
                util.assigned_bytes as f64 / (1 << 30) as f64,
                util.utilisation_fraction() * 100.0,
                util.layer_count,
            )?;
        }
        Ok(())
    }
}
