//! Hardware memory probing.
//!
//! Supports three backends selected at compile time:
//! * `nvml`  (feature `nvml`, default) — NVIDIA Management Library via
//!   [`nvml-wrapper`].  Most accurate; works even when the GPU is busy.
//! * `sysfs` (feature `sysfs`) — Parses `/sys/class/drm/…` and
//!   `/proc/meminfo`.  Works on non-NVIDIA hardware and inside containers
//!   without NVML.
//! * `mock`  (feature `mock`) — Returns deterministic fake values; for
//!   unit tests and CI environments with no GPU.

use std::fmt;
use serde::{Deserialize, Serialize};
use thiserror::Error;

/// Error variants for hardware probing.
#[derive(Debug, Error)]
pub enum ProbeError {
    /// NVML initialisation or query failed.
    #[error("NVML error: {0}")]
    Nvml(String),
    /// Sysfs / procfs read failed.
    #[error("sysfs/procfs error: {0}")]
    Sysfs(String),
    /// No suitable probing backend compiled in.
    #[error("no hardware probing backend available")]
    NoBackend,
}

/// Memory snapshot for a single device (GPU or CPU/system).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DeviceMemory {
    /// Total physical memory in bytes.
    pub total: u64,
    /// Currently free (unallocated) bytes.
    pub free: u64,
    /// Bytes reserved by the current process (best-effort).
    pub process_used: u64,
}

impl DeviceMemory {
    /// Bytes available for new allocations, with a configurable safety margin.
    #[must_use]
    pub fn available_with_margin(&self, margin_fraction: f64) -> u64 {
        let usable = (self.free as f64 * (1.0 - margin_fraction)) as u64;
        usable
    }
}

impl fmt::Display for DeviceMemory {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "total={:.1} GiB  free={:.1} GiB  proc={:.1} GiB",
            gib(self.total),
            gib(self.free),
            gib(self.process_used),
        )
    }
}

fn gib(bytes: u64) -> f64 {
    bytes as f64 / (1024.0 * 1024.0 * 1024.0)
}

/// A single GPU device.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GpuDevice {
    /// Zero-based CUDA/ordinal index.
    pub index: u32,
    /// Human-readable name (e.g. `"NVIDIA GeForce RTX 4090"`).
    pub name: String,
    /// Current memory snapshot.
    pub memory: DeviceMemory,
    /// PCIe bus identifier, if available.
    pub pci_bus_id: Option<String>,
}

/// A complete hardware memory snapshot.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HardwareProbe {
    /// All detected GPU devices.
    pub gpus: Vec<GpuDevice>,
    /// Host (CPU) system memory.
    pub system_ram: DeviceMemory,
}

impl HardwareProbe {
    /// Capture a fresh snapshot using the best available backend.
    ///
    /// # Errors
    /// Returns [`ProbeError`] if no backend succeeds.
    pub fn capture() -> Result<Self, ProbeError> {
        #[cfg(feature = "mock")]
        return Ok(Self::mock());

        #[cfg(feature = "nvml")]
        {
            match Self::capture_nvml() {
                Ok(p) => return Ok(p),
                Err(e) => {
                    tracing::warn!("NVML probe failed ({e}), falling back to sysfs");
                }
            }
        }

        #[cfg(any(feature = "sysfs", not(feature = "nvml")))]
        return Self::capture_sysfs();

        #[allow(unreachable_code)]
        Err(ProbeError::NoBackend)
    }

    /// Total VRAM available across all GPUs.
    #[must_use]
    pub fn total_vram_free(&self) -> u64 {
        self.gpus.iter().map(|g| g.memory.free).sum()
    }

    /// Primary GPU (index 0), if present.
    #[must_use]
    pub fn primary_gpu(&self) -> Option<&GpuDevice> {
        self.gpus.first()
    }

    // ── NVML backend ────────────────────────────────────────────────────────

    #[cfg(feature = "nvml")]
    fn capture_nvml() -> Result<Self, ProbeError> {
        use nvml_wrapper::Nvml;

        let nvml = Nvml::init().map_err(|e| ProbeError::Nvml(e.to_string()))?;
        let count = nvml
            .device_count()
            .map_err(|e| ProbeError::Nvml(e.to_string()))?;

        let mut gpus = Vec::with_capacity(count as usize);
        for i in 0..count {
            let dev = nvml
                .device_by_index(i)
                .map_err(|e| ProbeError::Nvml(e.to_string()))?;
            let name = dev
                .name()
                .map_err(|e| ProbeError::Nvml(e.to_string()))?;
            let mem_info = dev
                .memory_info()
                .map_err(|e| ProbeError::Nvml(e.to_string()))?;
            let pci = dev.pci_info().ok().map(|p| p.bus_id);

            // Best-effort: compute processes using this device.
            let proc_used: u64 = dev
                .running_compute_processes()
                .unwrap_or_default()
                .iter()
                .filter_map(|p| p.used_gpu_memory)
                .sum();

            gpus.push(GpuDevice {
                index: i,
                name,
                memory: DeviceMemory {
                    total: mem_info.total,
                    free: mem_info.free,
                    process_used: proc_used,
                },
                pci_bus_id: pci,
            });
        }

        let system_ram = Self::probe_system_ram();
        Ok(Self { gpus, system_ram })
    }

    // ── sysfs / procfs backend ───────────────────────────────────────────────

    #[cfg(any(feature = "sysfs", not(feature = "nvml"), not(feature = "mock")))]
    fn capture_sysfs() -> Result<Self, ProbeError> {
        // For NVIDIA: /sys/class/drm/card*/device/mem_info_vram_total etc.
        // Fallback: run `nvidia-smi --query-gpu` and parse stdout.
        let gpus = Self::sysfs_gpus()?;
        let system_ram = Self::probe_system_ram();
        Ok(Self { gpus, system_ram })
    }

    #[cfg(any(feature = "sysfs", not(feature = "nvml"), not(feature = "mock")))]
    fn sysfs_gpus() -> Result<Vec<GpuDevice>, ProbeError> {
        // Try nvidia-smi CSV output first — most portable.
        let output = std::process::Command::new("nvidia-smi")
            .args([
                "--query-gpu=index,name,memory.total,memory.free,pci.bus_id",
                "--format=csv,noheader,nounits",
            ])
            .output();

        let output = match output {
            Ok(o) if o.status.success() => o,
            Ok(o) => {
                let msg = String::from_utf8_lossy(&o.stderr).to_string();
                return Err(ProbeError::Sysfs(format!("nvidia-smi failed: {msg}")));
            }
            Err(e) => {
                return Err(ProbeError::Sysfs(format!("nvidia-smi not found: {e}")));
            }
        };

        let stdout = String::from_utf8_lossy(&output.stdout);
        let mut gpus = Vec::new();

        for line in stdout.lines() {
            let parts: Vec<&str> = line.split(',').map(str::trim).collect();
            if parts.len() < 5 {
                continue;
            }
            let index: u32 = parts[0].parse().unwrap_or(0);
            let name = parts[1].to_string();
            // nvidia-smi returns MiB
            let total_mib: u64 = parts[2].parse().unwrap_or(0);
            let free_mib: u64 = parts[3].parse().unwrap_or(0);
            let pci_bus_id = Some(parts[4].to_string());

            gpus.push(GpuDevice {
                index,
                name,
                memory: DeviceMemory {
                    total: total_mib * 1024 * 1024,
                    free: free_mib * 1024 * 1024,
                    process_used: (total_mib - free_mib) * 1024 * 1024,
                },
                pci_bus_id,
            });
        }

        Ok(gpus)
    }

    // ── Shared helpers ───────────────────────────────────────────────────────

    fn probe_system_ram() -> DeviceMemory {
        use sysinfo::System;
        let mut sys = System::new_all();
        sys.refresh_all();

        let total = sys.total_memory();
        let free = sys.available_memory();
        let used = sys.used_memory();

        DeviceMemory {
            total,
            free,
            process_used: used,
        }
    }

    // ── Mock backend ─────────────────────────────────────────────────────────

    #[cfg(feature = "mock")]
    fn mock() -> Self {
        // Simulate an RTX 4090 (24 GiB VRAM) + 128 GiB system RAM.
        const GIB: u64 = 1024 * 1024 * 1024;
        Self {
            gpus: vec![GpuDevice {
                index: 0,
                name: "Mock RTX 4090 (24 GiB)".into(),
                memory: DeviceMemory {
                    total: 24 * GIB,
                    free: 22 * GIB,
                    process_used: 2 * GIB,
                },
                pci_bus_id: Some("00000000:01:00.0".into()),
            }],
            system_ram: DeviceMemory {
                total: 128 * GIB,
                free: 96 * GIB,
                process_used: 32 * GIB,
            },
        }
    }
}

impl fmt::Display for HardwareProbe {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        writeln!(f, "=== Hardware Snapshot ===")?;
        for gpu in &self.gpus {
            writeln!(f, "  GPU[{}] {}  {}", gpu.index, gpu.name, gpu.memory)?;
        }
        writeln!(f, "  SYS RAM  {}", self.system_ram)?;
        Ok(())
    }
}
